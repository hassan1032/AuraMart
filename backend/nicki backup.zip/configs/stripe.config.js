
import Stripe from "stripe";
import os from "os";
const hostname = os.hostname() || "";
const isProd =
    process.env.NODE_ENV === "production" ||
    hostname.includes("ip-") ||
    hostname.includes("ec2") ||
    hostname.includes("mackfralane");
export const stripeConfig = {
    secretKey: "sk_test_51SKcoj3w7B77SvHySxr8V07hS3quVKBtc2Ovn7yqX4r8TOHYqGPL4TmfuJZD5ORlJokAlb0KoafSMajfQq0wj0uS00Z0HGLURX",
    publishableKey: "pk_test_51SKcoj3w7B77SvHyDy14HCsoRPo87LYXIvOnw7uwNM2jZXkpuJLfFAkGy0KMl5SBULvsa0VGPn6qw3yMjae3hkCe00ELRORliD",
    frontendBaseUrl: isProd
        ? "https://main.d1pt21imyin88y.amplifyapp.com" // ✅ Live frontend
        : "http://localhost:5173", // ✅ Local frontend
    webhookSecret: "whsec_Z594wCRuXzloyQX9j2KVkIYdB8CcYvS4",
};

const stripe = new Stripe(stripeConfig.secretKey);
export default stripe;
