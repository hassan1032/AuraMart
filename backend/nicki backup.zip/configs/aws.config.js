
// export const awsConfig = {
//     accessKeyId: "AKIAVVIJY7Q64WQ5VOFX",
//     secretAccessKey: "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",
//     bucket: "nicki1",
// };
export const awsConfig = {
    accessKeyId: "AKIAXWKZHLRUFQO2SIMZ",
    secretAccessKey: "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",
    bucket: "nickibucket12",
};
