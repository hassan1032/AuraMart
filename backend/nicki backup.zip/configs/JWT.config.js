export default {
    // 🔹 JWT Config
    jwtSecretKey: "mySuperSecretJWTKey_123456",
    cookieExpire: 15,

    // 🔹 Google OAuth Config
    googleClientId: "642638716953-5h7mh2h5omm9708htp0fo2sh8e8orngv.apps.googleusercontent.com",
    googleClientSecret: "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",

    // 🔹 Facebook OAuth (future use)
    facebookAppId: "790392013623091",
    facebookAppSecret: "15b2f75f10237ac86f761d2c2bd7fb5d",
    callbackURL: "https://nickiapi.sndigitech.com/auth/facebook/callback",
    profileFields: ['id', 'emails', 'name'],

    // 🔹 Apple OAuth (future use)
    appleClientId: "YOUR_APPLE_CLIENT_ID_HERE",
    appleTeamId: "YOUR_APPLE_TEAM_ID_HERE",
    appleKeyId: "YOUR_APPLE_KEY_ID_HERE",
    applePrivateKey: "YOUR_APPLE_PRIVATE_KEY_HERE",
};
