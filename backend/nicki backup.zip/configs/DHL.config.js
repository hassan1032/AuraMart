export const DHL_CONFIG = {
    // Common Base URL
    baseURL: "https://api-eu.dhl.com",

    // Replace this once you get production key
    apiKey: "SANDBOX_OR_PRODUCTION_KEY_HERE",

    // Switch to "production" after approval
    environment: "sandbox", // "sandbox" | "production"

    // API Endpoints (as per DHL Docs)
    createShipmentPath: "/ecommerce/shipments",
    trackPath: "/track/shipments",

    // Sandbox demo tracking prefix
    sandboxDemoTrackingPrefix: "DHLTEST",
};
