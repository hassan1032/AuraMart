
/// This credentials For DB _____________________
export const dbConfig = {
    password: '0786',
    source: {
        user: 'lovely',
        pass: 'lovely',
        cluster: 'cluster0.wsxbd.mongodb.net',
        dbName: 'test',
    },
    target: {
        user: 'sndigitech32',
        pass: 'akeGTz5p6A6JdSQi',
        cluster: 'cluster0.zepjaka.mongodb.net',
        dbName: 'Sndigitech-Production',
    }
};

/// This credentials For S3 bucket _______________________

// config/s3.config.js
export const s3Config = {
    password: '786',
    source: {
        accessKeyId: 'AKIAVVIJY7Q64WQ5VOFX',
        secretAccessKey: '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',
        region: 'eu-north-1',
        bucket: 'nicki1',
    },
    target: {
        accessKeyId: 'AKIAXWKZHLRUFQO2SIMZ',
        secretAccessKey: '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',
        region: 'eu-north-1',
        bucket: 'nickibucket12',
    }
};

