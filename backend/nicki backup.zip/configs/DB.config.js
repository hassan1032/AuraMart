import "dotenv/config";

export const dbConfig = {
    url: 'mongodb+srv://mackfrlane:8Bvf69bkZgNjFX6W@mackfrnlane.rkfof5k.mongodb.net/mackfarlane'
};
export const PORT = process.env.hasOwnProperty("APP_ENV")
    ? process.env.PORT
    : "4050";