const config = {
    twilio: {
        accountSID: 'ACd9f4dc70fbb732635dff207967d6d194',
        authToken: '3d695a1efe3f243ab9a7abaa995cf977',
        phoneNumber: '+1 909 610 1060'
    }
};

export default config;
