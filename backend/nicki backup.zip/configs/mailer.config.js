export const emailConfig = {
    service: "Gmail",
    type: "OAuth2",
    user: "apponpurpose@gmail.com",
    clientId: "909099997886-uukkal2mpdbtrnhg1q5lm8212bodn3jh.apps.googleusercontent.com",
    clientSecret: "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",
    redirectUri: "https://developers.google.com/oauthplayground",
    refreshToken: "1//04NI5W43cPu3cCgYIARAAGAQSNwF-L9IrRdMwDExTbsgW2T8pts3dyVeZwhgFaxQKIFspPkKC_diJS8T7Ya4CG2poLMPn6sQGuLs",
    accessToken: "ya29.a0AW4XtxhG6G-uO9CSXZ679nUVpQ8zQeyTZJqYWUzWCI6exShTGxoHBySUzpJcxBO8n1dY6QMTvoucTb3dOOyYTKscpFEx7XmSFUp8dr84OkG3d5oQnmiFuUqCAhPDlWw99pPm0iQOxpVC1eKqo_NaVp2DjAx6DVlQF3eCX-jtaCgYKAQESARQSFQHGX2MiPPazA39E2L2UDwXsNdzwDg0175",
    expires: "1494388182480",
};

// export const emailConfig = {
//     service: "Gmail",
//     type: "OAuth2",
//     user: "tiddoapp@gmail.com",
//     clientId: "417458290523-3jkbbmfkfi8cgract1tlh3is5odec065.apps.googleusercontent.com",
//     clientSecret: "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",
//     redirectUri: "https://developers.google.com/oauthplayground",
//     refreshToken: "1//04bg60YUwSfTUCgYIARAAGAQSNwF-L9IrNDJ9fsM-ydJV6Xi-Wk2SfqN5smBZtCnb1tX8hzjCK48gIqqmny4eBjM7qVn6C0FvkRE",
//     accessToken: "ya29.a0ARW5m74ZdbM8SyKtdk-lTvLjaf76xMnt5GhAL9HsQKPFhzYk50c2QXEr1_7zqu_XD3Ut1VqpjjrQgLDsoOUB783PUHxmjn7Ij6_2jCu0fZXmQszDwPyIXrSBn6T-BvdEOn0pai5dFkf2njvl6PuQLlDAbVc8nAKHsRi7mqfqaCgYKAeoSARMSFQHGX2MidqXOTXVmwBGRW36ot_MIaQ0175",
//     expires: "1494388182480",
// };
