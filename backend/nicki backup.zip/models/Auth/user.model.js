
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
const { Schema, model } = mongoose;
const auth = new Schema({
    userId: { type: String, default: "" },
    email: { type: String, lowercase: true, trim: true, default: '' },
    name: { type: String, default: '' },
    socialName: { type: String, default: '' },
    contact: { type: String, trim: true, default: '' },
    countryCode: { type: String, default: '' },
    profilePic: { type: String, default: '' },
    url: { type: String, },
    provider: { type: String, enum: ['google', 'facebook', 'apple', 'manual'], default: 'manual' },
    providerId: { type: String, default: "" },
    role: { type: String, enum: ['User', 'Admin'], default: 'User' },
    OTP: { type: String, default: '' },
    otpExpiry: { type: Date, default: null },
    isVerified: { type: Boolean, default: false },
},
    { versionKey: false, timestamps: true });
auth.index();
auth.pre("save", async function (next) {
    if (this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});
auth.methods.comparePassword = function (password) {
    return bcrypt.compare(password, this.password);
};

auth.methods.generateJsonWebToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET_KEY);
};

export default model('auth', auth);