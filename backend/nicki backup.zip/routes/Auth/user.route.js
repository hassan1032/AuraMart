import { completeUserProfile, verifyEmail, requestLoginOtp, userLoginOtp, sendContactOTP, verifyContact, resendContactOTP, getUserprofile, sendOtpEmailUser, googleLogin, facebookLogin } from "../../controllers/Auth/user.controller.js";
import { auth } from "../../middlewares/auth.middleware.js"


export default (app) => {
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Credentials', 'true');
        res.header('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
        res.header('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
        res.header('Cache-Control', 'no-cache');
        res.header('Content-Type', 'application/json; charset=utf-8');
        next();
    });
    // Auth Routes User
    app.post('/api/auth/send/otp/email/user', sendOtpEmailUser)
    app.post('/api/auth/register/user', completeUserProfile)
    app.post('/api/auth/verify/account/user', verifyEmail)
    app.post('/api/auth/verify/contact/user', verifyContact)
    app.post('/api/auth/resend/otp/user', resendContactOTP)
    app.post('/api/auth/send/contact/otp/user', sendContactOTP)
    app.post('/api/auth/request/login/otp/user', requestLoginOtp)
    app.post('/api/auth/login/user', userLoginOtp)
    app.post('/api/auth/login/google/user', googleLogin)
    app.post('/api/auth/login/facebook/user', facebookLogin)
    app.post('/api/auth/get/profile/user', auth, getUserprofile)
};