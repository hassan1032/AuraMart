
import { addToWishlist, getWishlist, removeFromWishlist } from "../../controllers/Product Management/whislist.controller.js";
export default (app) => {
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Credentials', 'true');
        res.header('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
        res.header('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
        res.header('Cache-Control', 'no-cache');
        res.header('Content-Type', 'application/json; charset=utf-8');
        next();
    });
    app.post('/api/add/whislist/product/user', addToWishlist)
    app.get('/api/get/all/whislist/product/user', getWishlist)
    app.delete('/api/remove/whislist/product/user', removeFromWishlist)
}
