
import { createOrder, getAllOrders, getOrderById, getUserOrders, createOrderFromCart, } from "../../controllers/Product Management/order.controller.js";
import { auth } from "../../middlewares/auth.middleware.js"
export default (app) => {
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Credentials', 'true');
        res.header('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
        res.header('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
        res.header('Cache-Control', 'no-cache');
        res.header('Content-Type', 'application/json; charset=utf-8');
        next();
    });
    app.post('/api/create/order/user', createOrder)
    app.post('/api/create/order/cart/user', createOrderFromCart)
    app.post('/api/get/single/order/admin', getOrderById)
    app.get('/api/get/all/order/admin', getAllOrders)
    app.get('/api/get/order/by/user', auth, getUserOrders)


}
