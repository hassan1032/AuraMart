import orderModel from "../../models/Product Management/order.model.js";
import productModel from "../../models/Product Management/product.model.js";
import accessoryModel from "../../models/Product Management/accessory.model.js";
import priceModel from "../../models/Product Management/price.model.js";
import { generateUniqueSlug } from '../../helpers/genrateSlug.helper.js'
import authModel from "../../models/Auth/user.model.js"
import getCountryFromLatLon from "../../helpers/location.helper.js";
import generateOrderCode from "../../helpers/genrateOrderCode.helper.js";
import cartModel from "../../models/Product Management/addToCart.model.js"
import mongoose from "mongoose";

// Create Order ::
export const createOrder = async (req, res) => {
    try {
        const { userId, items, shippingAddress } = req.body;
        const lat = parseFloat(req.query.lat);
        const lon = parseFloat(req.query.lon);
        let detectedCountry = null;
        if (!isNaN(lat) && !isNaN(lon)) {
            detectedCountry = getCountryFromLatLon(lat, lon);
        }
        if (!items || items.length === 0) {
            return res.status(400).json({ success: false, message: "No items in order" });
        }
        const orderCode = await generateOrderCode();
        const slug = await generateUniqueSlug(orderCode, orderModel, "orderUrl");
        let totalAmount = 0;
        const orderItems = [];
        for (let item of items) {
            const { productId, accessoryId, priceId, quantity, selectedSize, selectedColor } = item;
            const priceData = await priceModel.findById(priceId);
            if (!priceData) {
                return res.status(400).json({ success: false, message: `Invalid priceId: ${priceId}` });
            }
            const unitPrice = priceData.sellingPrice;
            const totalPrice = unitPrice * quantity;
            totalAmount += totalPrice;
            if (productId) {
                const product = await productModel.findById(productId);
                if (!product) {
                    return res.status(404).json({ success: false, message: `Product not found (ID: ${productId})` });
                }
                if (product.stockQuantity < quantity) {
                    return res.status(400).json({ success: false, message: `Insufficient stock for product "${product.name}". Available: ${product.stockQuantity}, Requested: ${quantity}` });
                }
                product.stockQuantity -= quantity;
                product.reservedQuantity += quantity;
                await product.save();
            }
            if (accessoryId) {
                const accessory = await accessoryModel.findById(accessoryId);
                if (!accessory) {
                    return res.status(404).json({ success: false, message: `Accessory not found (ID: ${accessoryId})` });
                }
                if (accessory.stockQuantity < quantity) {
                    return res.status(400).json({
                        success: false,
                        message: `Insufficient stock for accessory "${accessory.name}". Available: ${accessory.stockQuantity}, Requested: ${quantity}`
                    });
                }
                accessory.stockQuantity -= quantity;
                accessory.reservedQuantity += quantity;
                await accessory.save();
            }
            orderItems.push({
                productId,
                accessoryId,
                priceId,
                quantity,
                unitPrice,
                totalPrice,
                selectedSize,
                selectedColor,
                trackingNumber: null,
            });
        }
        const newOrder = await orderModel.create({
            userId,
            items: orderItems,
            totalAmount,
            shippingAddress,
            orderCode,
            orderUrl: slug,
            detectedCountry,
            status: "pending",
            paymentStatus: "notPaid",
        });
        return res.status(201).json({ success: true, message: "Order created successfully", data: newOrder, });
    } catch (error) {
        console.error("Create Order Error:", error);
        return res.status(500).json({ success: false, message: "Server error while creating order", error: error.message, });
    }
};
// Create Order For Cart ::
export const createOrderFromCart = async (req, res) => {
    try {
        const { userId, shippingAddress } = req.body;
        const lat = parseFloat(req.query.lat);
        const lon = parseFloat(req.query.lon);
        if (!userId) {
            return res.status(400).json({ success: false, message: "UserId is required" });
        }
        let detectedCountry = null;
        if (!isNaN(lat) && !isNaN(lon)) {
            detectedCountry = getCountryFromLatLon(lat, lon);
        }
        const cart = await cartModel.findOne({ userId });
        if (!cart || cart.items.length === 0) {
            return res.status(400).json({ success: false, message: "Cart is empty" });
        }
        const orderCode = await generateOrderCode();
        const slug = await generateUniqueSlug(orderCode, orderModel, "orderUrl");
        let totalAmount = 0;
        const orderItems = [];
        for (let item of cart.items) {
            const { productId, accessoryId, priceId, quantity, selectedSize, selectedColor } = item;
            const priceData = await priceModel.findById(priceId);
            if (!priceData) {
                return res.status(400).json({ success: false, message: `Invalid priceId: ${priceId}` });
            }
            const unitPrice = priceData.sellingPrice;
            const totalPrice = unitPrice * quantity;
            totalAmount += totalPrice;
            if (productId) {
                const product = await productModel.findById(productId);
                if (!product) {
                    return res.status(404).json({ success: false, message: `Product not found (ID: ${productId})` });
                }
                if (product.stockQuantity < quantity) {
                    return res.status(400).json({
                        success: false,
                        message: `Insufficient stock for product "${product.name}". Available: ${product.stockQuantity}, Requested: ${quantity}`,
                    });
                }
                product.stockQuantity -= quantity;
                product.reservedQuantity += quantity;
                await product.save();
            }
            if (accessoryId) {
                const accessory = await accessoryModel.findById(accessoryId);
                if (!accessory) {
                    return res.status(404).json({ success: false, message: `Accessory not found (ID: ${accessoryId})` });
                }
                if (accessory.stockQuantity < quantity) {
                    return res.status(400).json({
                        success: false,
                        message: `Insufficient stock for accessory "${accessory.name}". Available: ${accessory.stockQuantity}, Requested: ${quantity}`,
                    });
                }
                accessory.stockQuantity -= quantity;
                accessory.reservedQuantity += quantity;
                await accessory.save();
            }
            orderItems.push({ productId, accessoryId, priceId, quantity, unitPrice, totalPrice, selectedSize, selectedColor, trackingNumber: null, });
        }
        const newOrder = await orderModel.create({
            userId,
            items: orderItems,
            orderUrl: slug,
            totalAmount,
            shippingAddress, orderCode, detectedCountry, status: "pending", paymentStatus: "notPaid",
        });
        cart.items = [];
        await cart.save();
        return res.status(201).json({ success: true, message: "Order placed successfully from cart", data: newOrder, });

    } catch (error) {
        console.error("Create Order From Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while creating order from cart", error: error.message, });
    }
};
// Get All Order ::
export const getAllOrders = async (req, res) => {
    try {
        const orders = await orderModel.aggregate([
            {
                $lookup: {
                    from: "auths",
                    localField: "userId",
                    foreignField: "_id",
                    as: "user"
                }
            },
            { $unwind: { path: "$user", preserveNullAndEmptyArrays: true } },

            {
                $lookup: {
                    from: "productschemas",
                    localField: "items.productId",
                    foreignField: "_id",
                    as: "products",
                },
            },
            {
                $lookup: {
                    from: "accessoryschemas",
                    localField: "items.accessoryId",
                    foreignField: "_id",
                    as: "accessories",
                },
            },
            {
                $lookup: {
                    from: "priceschemas",
                    localField: "items.priceId",
                    foreignField: "_id",
                    as: "prices",
                },
            },
            {
                $project: {
                    orderCode: 1,
                    totalAmount: 1,
                    shippingAddress: 1,
                    detectedCountry: 1,
                    status: 1,
                    paymentStatus: 1,
                    orderUrl: 1,
                    createdAt: 1,
                    updatedAt: 1,
                    prices: 1,
                    user: 1,
                    items: 1,
                    products: 1,
                    accessories: 1,
                    prices: 1,
                },
            },
            { $sort: { createdAt: -1 } },
        ]);

        return res.status(200).json({
            success: true,
            message: "All orders fetched successfully (admin view).",
            count: orders.length,
            data: orders,
        });
    } catch (error) {
        console.error("Get All Orders Error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error while fetching orders",
            error: error.message,
        });
    }
};
// Get Single Order ::
export const getOrderById = async (req, res) => {
    try {
        const { idOrSlug } = req.body;
        if (!idOrSlug) {
            return res.status(400).json({
                success: false, message: "Order ID or Order URL is required",
            });
        }
        let matchCondition = {};
        if (mongoose.Types.ObjectId.isValid(idOrSlug)) {
            matchCondition = { _id: new mongoose.Types.ObjectId(idOrSlug) };
        } else {
            matchCondition = { orderUrl: idOrSlug };
        }
        const order = await orderModel.aggregate([
            {
                $match: matchCondition,
            },
            {
                $lookup: {
                    from: "auths",
                    localField: "userId",
                    foreignField: "_id",
                    as: "user",
                },
            },
            { $unwind: { path: "$user", preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: "productschemas",
                    localField: "items.productId",
                    foreignField: "_id",
                    as: "products",
                },
            },
            {
                $lookup: {
                    from: "accessoryschemas",
                    localField: "items.accessoryId",
                    foreignField: "_id",
                    as: "accessories",
                },
            },
            {
                $lookup: {
                    from: "priceschemas",
                    localField: "items.priceId",
                    foreignField: "_id",
                    as: "prices",
                },
            },
            {
                $addFields: {
                    items: {
                        $map: {
                            input: "$items",
                            as: "item",
                            in: {
                                $mergeObjects: [
                                    "$$item",
                                    {
                                        productData: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$products",
                                                        as: "prod",
                                                        cond: {
                                                            $eq: ["$$prod._id", "$$item.productId"],
                                                        },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                        accessoryData: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$accessories",
                                                        as: "acc",
                                                        cond: {
                                                            $eq: ["$$acc._id", "$$item.accessoryId"],
                                                        },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                        priceData: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$prices",
                                                        as: "prc",
                                                        cond: {
                                                            $eq: ["$$prc._id", "$$item.priceId"],
                                                        },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                    },
                                ],
                            },
                        },
                    },
                },
            },
            {
                $project: {
                    orderCode: 1,
                    totalAmount: 1,
                    shippingAddress: 1,
                    detectedCountry: 1,
                    status: 1,
                    paymentStatus: 1,
                    orderUrl: 1,
                    createdAt: 1,
                    items: 1,
                    user: {
                        firstName: 1,
                        lastName: 1,
                        email: 1,
                        contact: 1,
                        country: 1,
                    },
                },
            },
        ]);
        if (!order || order.length === 0) {
            return res.status(404).json({ success: false, message: "Order not found", });
        }
        const orderData = order[0];
        orderData.items = orderData.items.map((item) => {
            let selectedImage = null;
            const color = item.selectedColor?.toLowerCase();
            if (item.productData?.colorImages?.length) {
                const matched = item.productData.colorImages.find(
                    (img) => img.color.toLowerCase() === color
                );
                selectedImage =
                    matched?.thumbnail ||
                    matched?.additionalThumbnail?.[0] ||
                    null;
            }
            if (!selectedImage && item.accessoryData?.colorImages?.length) {
                const matched = item.accessoryData.colorImages.find(
                    (img) => img.color.toLowerCase() === color
                );
                selectedImage =
                    matched?.accessoryThumbnail ||
                    matched?.additionalThumbnail?.[0] ||
                    null;
            }

            return { ...item, selectedImage };
        });
        return res.status(200).json({ success: true, message: "Order fetched successfully", data: orderData, });
    } catch (error) {
        console.error("Get Order By ID Error:", error);
        return res.status(500).json({ success: false, message: "Server error while fetching order", error: error.message, });
    }
};
// Get Single User Order To Product ::
export const getUserOrders = async (req, res) => {
    try {
        const userId = req.userId;
        if (!userId) {
            return res.status(400).json({ success: false, message: "User ID is required.", });
        }
        const user = await authModel.findById(userId).lean();
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found.", });
        }
        const orders = await orderModel.aggregate([
            {
                $match: { userId: new mongoose.Types.ObjectId(userId) },
            },
            {
                $lookup: {
                    from: "productschemas",
                    localField: "items.productId",
                    foreignField: "_id",
                    as: "productDetails",
                },
            },
            {
                $lookup: {
                    from: "accessoryschemas",
                    localField: "items.accessoryId",
                    foreignField: "_id",
                    as: "accessoryDetails",
                },
            },
            {
                $lookup: {
                    from: "priceschemas",
                    localField: "items.priceId",
                    foreignField: "_id",
                    as: "priceDetails",
                },
            },
            {
                $addFields: {
                    items: {
                        $map: {
                            input: "$items",
                            as: "item",
                            in: {
                                $mergeObjects: [
                                    "$$item",
                                    {
                                        product: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$productDetails",
                                                        as: "prod",
                                                        cond: { $eq: ["$$prod._id", "$$item.productId"] },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                        accessory: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$accessoryDetails",
                                                        as: "acc",
                                                        cond: { $eq: ["$$acc._id", "$$item.accessoryId"] },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                        price: {
                                            $arrayElemAt: [
                                                {
                                                    $filter: {
                                                        input: "$priceDetails",
                                                        as: "price",
                                                        cond: { $eq: ["$$price._id", "$$item.priceId"] },
                                                    },
                                                },
                                                0,
                                            ],
                                        },
                                    },
                                ],
                            },
                        },
                    },
                },
            },
            { $sort: { createdAt: -1 } },
            {
                $project: {
                    _id: 1,
                    orderCode: 1,
                    userId: 1,
                    items: 1,
                    orderUrl: 1,
                    totalAmount: 1,
                    detectedCountry: 1,
                    status: 1,
                    paymentStatus: 1,
                    createdAt: 1,
                    updatedAt: 1,
                },
            },
        ]);
        if (!orders || orders.length === 0) {
            return res.status(200).json({
                success: true,
                message: "No orders found for this user.",
                user: {
                    _id: user._id,
                    name: user.name || "",
                    email: user.email || "",
                },
                data: [],
            });
        }
        return res.status(200).json({
            success: true, message: "User orders fetched successfully.", user: { _id: user._id, name: user.name || "", email: user.email || "", }, data: orders,
        });
    } catch (error) {
        console.error("GetUserOrders Error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error while fetching user orders.",
            error: error.message,
        });
    }
};


