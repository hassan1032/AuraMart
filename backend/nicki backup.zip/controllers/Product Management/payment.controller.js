import stripe, { stripeConfig } from "../../configs/stripe.config.js";
import orderModel from "../../models/Product Management/order.model.js";
import paymentLogModel from "../../models/Product Management/payment.model.js";
import mongoose from "mongoose";

//Create checkout session
export const createCheckoutSession = async (req, res) => {
    try {
        const { orderId } = req.body;
        const order = await orderModel
            .findById(orderId)
            .populate({ path: "items.productId", model: "productSchema" })
            .populate({ path: "items.accessoryId", model: "accessorySchema" })
            .populate({ path: "items.priceId", model: "PriceSchema" })
            .lean();
        if (!order) {
            return res.status(404).json({ success: false, message: "Order not found" });
        }
        const currencyMap = {
            "₹": "inr",
            "INR": "inr",
            "IN": "inr",
            "£": "gbp",
            "GBP": "gbp",
            "UK": "gbp",
            "€": "eur",
            "EUR": "eur",
            "ITALY": "eur",
            "د.إ": "aed",
            "AED": "aed",
            "DUBAI": "aed",
            "USD": "usd",
            "$": "usd"
        };
        const line_items = order.items.map((item) => {
            const name = item.productId?.productName || item.accessoryId?.accessoryName || "Unknown Item";
            const rawCurrency = item.priceId?.currency || order.currency || "USD";
            const currency = currencyMap[rawCurrency.toUpperCase()] || "usd";
            const price = item.priceId?.sellingPrice || item.unitPrice || 0;
            return {
                price_data: {
                    currency,
                    product_data: { name },
                    unit_amount: Math.round(price * 100),
                },
                quantity: item.quantity || 1,
            };
        });
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ["card"],
            mode: "payment",
            line_items,
            metadata: { orderId: order._id.toString() },
            success_url: `${stripeConfig.frontendBaseUrl}/payment-success?order=${order.orderCode}`,
            cancel_url: `${stripeConfig.frontendBaseUrl}/payment-cancel?order=${order.orderCode}`
        });
        return res.status(200).json({ success: true, url: session.url, sessionId: session.id, });
    } catch (err) {
        console.error("❌ Stripe session error:", err);
        return res.status(500).json({ success: false, message: err.message });
    }
};
// Verify session::
export const verifySession = async (req, res) => {
    try {
        const { sessionId } = req.query;
        if (!sessionId)
            return res.status(400).json({ success: false, message: "session_id required" });

        const session = await stripe.checkout.sessions.retrieve(sessionId, {
            expand: ["payment_intent"],
        });
        return res.status(200).json({
            success: true,
            paymentStatus: session.payment_status,
            orderId: session.metadata?.orderId,
        });
    } catch (err) {
        console.error("verifySession error:", err);
        return res.status(500).json({ success: false, message: err.message });
    }
};
// verify Payment in Webhook For safety Perpose ::
export const stripeWebhook = async (req, res) => {
    const sig = req.headers["stripe-signature"];
    const webhookSecret = stripeConfig.webhookSecret;
    let event;
    try {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
        console.error("❌ Webhook signature verification failed:", err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    try {
        const existingEvent = await paymentLogModel.findOne({ "rawEvent.id": event.id });
        if (existingEvent) {
            console.log("⚠️ Duplicate event ignored:", event.id);
            return res.status(200).json({ received: true });
        }
        switch (event.type) {
            case "checkout.session.completed": {
                const session = event.data.object;
                const orderId = session.metadata?.orderId;
                const existingPayment = await paymentLogModel.findOne({ stripeSessionId: session.id });
                if (existingPayment) {
                    console.log("⚠️ Payment already logged, skipping duplicate entry");
                    break;
                }
                await paymentLogModel.create({
                    orderId: orderId ? new mongoose.Types.ObjectId(orderId) : null,
                    stripeSessionId: session.id,
                    paymentIntentId: session.payment_intent || null,
                    amount: session.amount_total || 0,
                    currency: session.currency || "inr",
                    status: "checkout.session.completed",
                    rawEvent: {
                        id: event.id,
                        type: event.type,
                        data: session,
                    },
                });
                if (orderId) {
                    const order = await orderModel.findById(orderId);
                    if (order && order.paymentStatus !== "paid") {
                        order.paymentStatus = "paid";
                        await order.save();
                        console.log("✅ Order payment marked as paid:", orderId);
                    } else {
                        console.log("ℹ️ Order already paid or not found:", orderId);
                    }
                }
                break;
            }
            case "payment_intent.payment_failed": {
                const pi = event.data.object;
                const exists = await paymentLogModel.findOne({ paymentIntentId: pi.id });
                if (exists) {
                    console.log("⚠️ Duplicate failed intent ignored");
                    break;
                }
                await paymentLogModel.create({
                    orderId: pi.metadata?.orderId ? new mongoose.Types.ObjectId(pi.metadata.orderId) : null,
                    stripeSessionId: pi.id,
                    paymentIntentId: pi.id,
                    amount: pi.amount || 0,
                    currency: pi.currency,
                    status: "payment_failed",
                    rawEvent: {
                        id: event.id,
                        type: event.type,
                        data: pi,
                    },
                });
                break;
            }
            default:
                console.log(`⚠️ Unhandled event type: ${event.type}`);
        }
        res.json({ received: true });
    } catch (err) {
        console.error("💥 Error processing webhook:", err);
        res.status(500).send();
    }
};

