import cartModel from "../../models/Product Management/addToCart.model.js";
import getCountryFromLatLon from "../../helpers/location.helper.js"
import priceModel from "../../models/Product Management/price.model.js"
import productModel from "../../models/Product Management/product.model.js";
import accessoryModel from "../../models/Product Management/accessory.model.js";

// 🛒 Add to Cart
export const addToCart = async (req, res) => {
    try {
        const { userId, productId, accessoryId, priceId, quantity, selectedSize, selectedColor } = req.body;
        if (!userId) return res.status(400).json({ success: false, message: "User ID is required" });
        if (!productId && !accessoryId)
            return res.status(400).json({ success: false, message: "Either Product ID or Accessory ID is required" });
        if (!priceId) return res.status(400).json({ success: false, message: "Price ID is required" });
        const priceData = await priceModel.findById(priceId);
        if (!priceData) {
            return res.status(400).json({ success: false, message: `Invalid priceId: ${priceId}` });
        }
        if (productId) {
            const productExists = await productModel.findById(productId);
            if (!productExists) return res.status(400).json({ success: false, message: `Invalid productId: ${productId}` });
        }
        if (accessoryId) {
            const accessoryExists = await accessoryModel.findById(accessoryId);
            if (!accessoryExists) return res.status(400).json({ success: false, message: `Invalid accessoryId: ${accessoryId}` });
        }
        let cart = await cartModel.findOne({ userId });
        if (!cart) cart = new cartModel({ userId, items: [] });
        const existingItem = cart.items.find(
            (item) =>
                String(item.productId) === String(productId || item.productId) &&
                String(item.accessoryId) === String(accessoryId || item.accessoryId) &&
                String(item.priceId) === String(priceId) &&
                item.selectedSize === selectedSize &&
                item.selectedColor === selectedColor
        );
        if (existingItem) {
            existingItem.quantity += quantity || 1;
        } else {
            cart.items.push({ productId, accessoryId, priceId, quantity: quantity || 1, selectedSize, selectedColor, });
        }
        await cart.save();
        return res.status(200).json({ success: true, message: "Item added to cart successfully", data: cart });

    } catch (error) {
        console.error("Add to Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while adding to cart", error: error.message });
    }
};
// 🛒 Get Cart
export const getCart = async (req, res) => {
    try {
        const { userId } = req.query;
        const lat = parseFloat(req.query.lat);
        const lon = parseFloat(req.query.lon);
        if (!userId) {
            return res.status(400).json({ success: false, message: "UserId is required" });
        }
        let userCountry = null;
        if (!isNaN(lat) && !isNaN(lon)) {
            userCountry = getCountryFromLatLon(lat, lon);
        }
        const cart = await cartModel.findOne({ userId }).populate("items.productId").populate("items.accessoryId").populate("items.priceId");
        if (!cart) {
            return res.status(200).json({ success: true, message: "Cart is empty", data: [], cartCount: 0, cartTotal: 0, });
        }
        let cartTotal = 0;
        const updatedItems = cart.items.map((item) => {
            let selectedPrice = null;
            if (item.priceId) {
                const priceObj = item.priceId;
                if (userCountry) {
                    if (priceObj.country.toUpperCase() === userCountry.toUpperCase()) {
                        selectedPrice = priceObj;
                    }
                }
                if (!selectedPrice && priceObj.country === "UK") {
                    selectedPrice = priceObj;
                }
                if (!selectedPrice) {
                    selectedPrice = priceObj;
                }
            }
            const itemPrice = selectedPrice?.sellingPrice || 0;
            const totalForItem = itemPrice * (item.quantity || 1);
            cartTotal += totalForItem;
            return {
                ...item.toObject(),
                priceId: selectedPrice ? [selectedPrice] : [],
                totalForItem,
            };
        });
        const cartCount = updatedItems.length;
        return res.status(200).json({ success: true, message: "Cart fetched successfully", data: { ...cart.toObject(), items: updatedItems, cartTotal, }, cartCount, });

    } catch (error) {
        console.error("Get Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while fetching cart", error: error.message, });
    }
};
// 🗑️ Remove Single Item from Cart (by item._id)
export const removeFromCart = async (req, res) => {
    try {
        const { userId, itemId } = req.body;
        if (!userId || !itemId) {
            return res.status(400).json({ success: false, message: "UserId and itemId are required", });
        }
        const cart = await cartModel.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ success: false, message: "Cart not found", });
        }
        const updatedItems = cart.items.filter(
            item => String(item._id) !== String(itemId)
        );
        if (updatedItems.length === cart.items.length) {
            return res.status(404).json({ success: false, message: "Item not found in cart", });
        }
        cart.items = updatedItems;
        await cart.save();
        return res.status(200).json({ success: true, message: "Item removed from cart successfully", data: cart, });
    } catch (error) {
        console.error("Remove Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while removing item from cart", error: error.message, });
    }
};
// 🧹 Clear Entire Cart (remove all items)
export const clearCart = async (req, res) => {
    try {
        const { userId } = req.body;
        if (!userId) {
            return res.status(400).json({ success: false, message: "UserId is required", });
        }
        const cart = await cartModel.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ success: false, message: "Cart not found", });
        }
        cart.items = [];
        await cart.save();
        return res.status(200).json({ success: true, message: "Cart cleared successfully", });
    } catch (error) {
        console.error("Clear Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while clearing cart", error: error.message, });
    }
};
// Merge Cart Item After user Login ::
export const mergeCart = async (req, res) => {
    try {
        const { userId, guestItems } = req.body;
        if (!userId) {
            return res.status(400).json({ success: false, message: "UserId is required" });
        }
        if (!guestItems || guestItems.length === 0) {
            return res.status(400).json({ success: false, message: "Guest cart is empty" });
        }
        let cart = await cartModel.findOne({ userId });
        if (!cart) {
            cart = new cartModel({ userId, items: [] });
        }
        for (let guestItem of guestItems) {
            const { productId, accessoryId, priceId, selectedSize, selectedColor, quantity } = guestItem;
            const existingItem = cart.items.find(item =>
                String(item.productId || "") === String(productId || "") &&
                String(item.accessoryId || "") === String(accessoryId || "") &&
                String(item.priceId) === String(priceId) &&
                item.selectedSize === selectedSize &&
                item.selectedColor === selectedColor
            );
            if (existingItem) {
                existingItem.quantity += quantity || 1;
            } else {
                cart.items.push({ productId, accessoryId, priceId, quantity: quantity || 1, selectedSize, selectedColor });
            }
        }
        await cart.save();
        return res.status(200).json({ success: true, message: "Guest cart merged successfully", data: cart });
    } catch (error) {
        console.error("Merge Cart Error:", error);
        return res.status(500).json({ success: false, message: "Server error while merging cart", error: error.message });
    }
};
