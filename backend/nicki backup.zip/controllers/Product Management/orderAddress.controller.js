import AddressModel from "../../models/Product Management/orderAddress.model.js";
// add Order Address ::
export const addAddress = async (req, res) => {
    try {
        const {
            userId, name, contact, countryCode, addressLine, provinceState, postalCode, country, addressType, city, isDefault } = req.body;

        const requiredFields = { userId, name, city, contact, addressLine, provinceState, postalCode, country };
        for (let key in requiredFields) {
            if (!requiredFields[key]) {
                return res.status(400).json({ success: false, message: `${key} is required` });
            }
        }
        const existingAddresses = await AddressModel.find({ userId });
        let finalIsDefault = isDefault || false;
        if (existingAddresses.length === 0) {
            finalIsDefault = true;
        }
        if (finalIsDefault) {
            await AddressModel.updateMany({ userId }, { $set: { isDefault: false } });
        }
        const newAddress = await AddressModel.create({ userId, name, contact, countryCode, addressLine, provinceState, postalCode, country, city, addressType, isDefault: finalIsDefault });

        return res.status(201).json({ success: true, message: "Address added successfully", data: newAddress });
    } catch (error) {
        console.error("Add Address Error:", error);
        return res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};
// Get All Order Address ::
export const getAllAddresses = async (req, res) => {
    try {
        const { userId } = req.query;
        if (!userId) {
            return res.status(400).json({ success: false, message: "userId is required" });
        }
        const addresses = await AddressModel.find({ userId });
        return res.status(200).json({ success: true, message: "Addresses retrieved successfully", data: addresses });
    } catch (error) {
        console.error("Get All Addresses Error:", error);
        return res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};
// Get Single Address By ID::
export const getAddressById = async (req, res) => {
    try {
        const { AddressId } = req.params;
        if (!AddressId) {
            return res.status(400).json({ success: false, message: "Address ID is required" });
        }
        const address = await AddressModel.findById(AddressId);
        if (!address) {
            return res.status(404).json({ success: false, message: "Address not found" });
        }
        return res.status(200).json({ success: true, message: "Address retrieved successfully", data: address });
    } catch (error) {
        console.error("Get Address Error:", error);
        return res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};
// Update Order Address ::
export const updateAddress = async (req, res) => {
    try {
        const { addressId } = req.params;
        const updateData = req.body;
        if (!addressId) {
            return res.status(400).json({ success: false, message: "Address ID is required" });
        }
        const existingAddress = await AddressModel.findById(addressId);
        if (!existingAddress) {
            return res.status(404).json({ success: false, message: "Address not found" });
        }
        if (updateData.isDefault === true) {
            await AddressModel.updateMany(
                { userId: existingAddress.userId },
                { $set: { isDefault: false } }
            );
        }
        const updatedAddress = await AddressModel.findByIdAndUpdate(
            addressId,
            updateData,
            { new: true, runValidators: true }
        );
        return res.status(200).json({ success: true, message: "Address updated successfully", data: updatedAddress });
    } catch (error) {
        console.error("Update Address Error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error",
            error: error.message
        });
    }
};
// Delete Address ::
export const deleteAddress = async (req, res) => {
    try {
        const { addressId } = req.params;
        const deleted = await AddressModel.findByIdAndDelete(addressId);
        if (!deleted) {
            return res.status(404).json({ success: false, message: "Address not found" });
        }
        return res.status(200).json({ success: true, message: "Address deleted successfully" });
    } catch (error) {
        console.error("Delete Address Error:", error);
        return res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};


