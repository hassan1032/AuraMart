import whislistModel from "../../models/Product Management/whislist.model.js";
import getCountryFromLatLon from '../../helpers/location.helper.js'
import priceModel from "../../models/Product Management/price.model.js";

// Add Whislist
export const addToWishlist = async (req, res) => {
    try {
        const { userId, productId, accessoryId } = req.body;
        let wishlist = await whislistModel.findOne({ userId });
        if (!wishlist) {
            wishlist = new whislistModel({ userId, products: [], accessories: [] });
        }
        if (productId) {
            if (!wishlist.products.some(p => p.productId.toString() === productId)) {
                wishlist.products.push({ productId });
            }
        }
        if (accessoryId) {
            if (!wishlist.accessories.some(a => a.accessoryId.toString() === accessoryId)) {
                wishlist.accessories.push({ accessoryId });
            }
        }
        await wishlist.save();
        res.status(200).json({ success: true, message: "Added to wishlist", data: wishlist });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server error", error: err.message });
    }
};
// Get All Whislist ::
export const getWishlist = async (req, res) => {
    try {
        const { userId } = req.query;
        const lat = parseFloat(req.query.lat);
        const lon = parseFloat(req.query.lon);
        if (!userId) {
            return res.status(400).json({ success: false, message: "UserId is required" });
        }
        let detectedCountry = null;
        if (!isNaN(lat) && !isNaN(lon)) {
            detectedCountry = getCountryFromLatLon(lat, lon);
        }
        const wishlist = await whislistModel.findOne({ userId }).populate("products.productId").populate("accessories.accessoryId");
        if (!wishlist) {
            return res.status(404).json({ success: false, message: "No wishlist found for this user" });
        }
        let updatedProducts = [];
        let updatedAccessories = [];
        for (let item of wishlist.products) {
            if (!item.productId) {
                console.warn(` Missing product in wishlist for user ${userId}`);
                continue;
            }
            let product = item.productId.toObject ? item.productId.toObject() : item.productId;
            let query = { productId: product._id };
            if (detectedCountry) {
                query.country = detectedCountry;
            }
            const productPrices = await priceModel.find(query);
            product.prices = productPrices || [];
            updatedProducts.push({ ...item.toObject(), productId: product });
        }
        for (let item of wishlist.accessories) {
            if (!item.accessoryId) {
                console.warn(` Missing accessory in wishlist for user ${userId}`);
                continue;
            }
            let accessory = item.accessoryId.toObject ? item.accessoryId.toObject() : item.accessoryId;
            let query = { accessoryId: accessory._id };
            if (detectedCountry) {
                query.country = detectedCountry;
            }
            const accessoryPrices = await priceModel.find(query);
            accessory.prices = accessoryPrices || [];
            updatedAccessories.push({ ...item.toObject(), accessoryId: accessory });
        }
        return res.status(200).json({ success: true, message: "Wishlist retrieved successfully", detectedCountry, data: { products: updatedProducts, accessories: updatedAccessories, }, });
    } catch (error) {
        console.error("❌ Get Wishlist Error:", error);
        return res.status(500).json({ success: false, message: "Server error while fetching wishlist", error: error.message, });
    }
};
// Remove The Whislist :::
export const removeFromWishlist = async (req, res) => {
    try {
        const { userId, productId, accessoryId } = req.body;
        let wishlist = await whislistModel.findOne({ userId });
        if (!wishlist) {
            return res.status(404).json({ success: false, message: "Wishlist not found" });
        }
        if (productId) {
            wishlist.products = wishlist.products.filter(p => p.productId.toString() !== productId);
        }
        if (accessoryId) {
            wishlist.accessories = wishlist.accessories.filter(a => a.accessoryId.toString() !== accessoryId);
        }
        await wishlist.save();
        res.status(200).json({ success: true, message: "Removed from wishlist", data: wishlist });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server error", error: err.message });
    }
};
