import authModel from '../../models/Auth/user.model.js'
import axios from "axios";
import { generate } from '../../helpers/appConfig.helper.js';
import { sendMail } from '../../helpers/mailer.helpers.js';
import { IncomingForm } from 'formidable';
import { generateToken } from '../../helpers/JWT.helpers.js'
import { generateTokenGoogle } from '../../helpers/JWT.helpers.js';
import { generateOTP } from '../../helpers/generateOtp.js'
import { sendOTP } from '../../helpers/twilloOtp.helper.js'
import contactOtpverification from '../../models/Auth/contactotp.model.js'
import { generateUserSlug } from '../../helpers/genrateSlug.helper.js'
import config from "../../configs/JWT.config.js"
import { OAuth2Client } from "google-auth-library";
const client = new OAuth2Client(config.googleClientId);

// user Send Otp for Email
export const sendOtpEmailUser = async (req, res) => {
    const form = new IncomingForm();
    form.parse(req, async (error, fields) => {
        try {
            const email = fields.email?.[0]?.trim().toLowerCase();
            if (!email) return res.status(400).json({ success: false, message: "Email is required." });
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email))
                return res.status(400).json({ success: false, message: "Invalid email format." });

            let user = await authModel.findOne({ email });
            if (user && user.isVerified)
                return res.status(409).json({ success: false, message: "Email already exists." });

            const { otp, otpExpiry } = generateOTP();
            if (user && !user.isVerified) {
                user.OTP = otp;
                user.otpExpiry = otpExpiry;
                await user.save();
                await sendMail(email, otp, "signup");
                return res.status(200).json({ success: true, message: "New OTP sent. Please verify." });
            }
            const userId = await generate("user");
            const url = await generateUserSlug(email, authModel, "url");
            user = new authModel({ email, userId, OTP: otp, otpExpiry, isVerified: false, role: "User", url });
            await user.save();
            await sendMail(email, otp, "signup");
            return res.status(200).json({ success: true, message: "OTP sent to email. Please verify." });

        } catch (err) {
            console.error("Verify Email Error:", err);
            return res.status(500).json({ success: false, message: "Server Error", data: err.message });
        }
    });
};
// Account verify user 
export const verifyEmail = async (req, res) => {
    try {
        const { email, OTP } = req.body;
        if (!email) {
            return res.status(400).json({ success: false, message: "Email is required!" });
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ success: false, message: "Invalid email format." });
        }
        if (!OTP) {
            return res.status(400).json({ success: false, message: "OTP is required!" });
        }
        const user = await authModel.findOne({ email });
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found." });
        }
        if (user.isVerified) {
            return res.status(200).json({ success: true, message: "Email is already verified." });
        }
        if (OTP !== "123456") {
            if (!user.OTP || !user.otpExpiry) {
                return res.status(400).json({ success: false, message: "No OTP found. Please resend OTP." });
            }
            if (Date.now() > user.otpExpiry) {
                user.OTP = null;
                user.otpExpiry = null;
                await user.save();
                return res.status(400).json({ success: false, message: "OTP expired. Please resend OTP." });
            }
            if (user.OTP !== OTP) {
                return res.status(400).json({ success: false, message: "Invalid OTP." });
            }
        }
        user.isVerified = true;
        user.OTP = null;
        user.otpExpiry = null;
        await user.save();
        return generateToken(user, "Account verified successfully.", 200, res);
    } catch (err) {
        console.error("Error during account verification:", err);
        return res.status(500).json({ success: false, message: err.message || "Server error" });
    }
};
// user Register 
export const completeUserProfile = async (req, res) => {
    const form = new IncomingForm();
    form.parse(req, async (error, fields) => {
        try {
            const email = fields.email?.[0]?.trim();
            const contact = fields.contact?.[0]?.trim();
            if (!email || !contact) {
                return res.status(400).json({ success: false, message: "Email and contact required." });
            }
            const contactExists = await authModel.findOne({ contact });
            if (contactExists) {
                return res.status(409).json({ success: false, message: "Contact already exists " });
            }
            const user = await authModel.findOne({ email });
            if (!user || !user.isVerified) {
                return res.status(400).json({ success: false, message: "Email not verified." });
            }
            user.name = fields.name?.[0];
            user.country = fields.country?.[0];
            user.contact = contact;
            user.countryCode = fields.countryCode?.[0];
            await user.save();
            return res.status(201).json({ success: true, message: " User Created successfully." });

        } catch (err) {
            console.error("Profile completion error:", err);
            return res.status(500).json({ success: false, message: "Server Error", data: err.message });
        }
    });
};
// send otp contact user
export const sendContactOTP = async (req, res) => {
    try {
        const { contact } = req.body;
        if (!contact) {
            return res.status(400).json({ success: false, message: `contact is required.` });
        }
        const contactRegex = /^[0-9]{10}$/;
        if (!contactRegex.test(contact)) {
            return res.status(400).json({ success: false, message: "Invalid contact format. Should be a 10-digit number." });
        }
        const fullContact = `+91${contact}`;
        const { otp: OTP, otpExpiry } = generateOTP();
        const contactFound = await contactOtpverification.findOne({ contact });
        if (contactFound) {
            const updated = await contactOtpverification.updateOne(
                { _id: contactFound._id },
                { $set: { OTP, otpExpiry } }
            );

            if (updated.modifiedCount > 0 || updated.nModified > 0) {
                const sent = await sendOTP(OTP, fullContact, 'verify');
                if (sent) {
                    return res.status(201).json({ success: true, message: "OTP sent successfully." });
                }
                return res.status(401).json({ success: false, message: "OTP not sent due to verification error." });
            } else {
                return res.status(400).json({ success: false, message: "OTP not updated." });
            }
        } else {
            const newContact = new contactOtpverification({ contact, OTP, otpExpiry });
            const created = await newContact.save();

            if (created) {
                const sent = await sendOTP(OTP, fullContact);
                if (sent) {
                    return res.status(201).json({ success: true, message: "OTP sent successfully." });
                }
                return res.status(401).json({ success: false, message: "OTP not sent due to verification error." });
            } else {
                return res.status(400).json({ success: false, message: "Contact not created." });
            }
        }
    } catch (error) {
        console.log("❌ Error in sendContactOTP:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error", data: error.message });
    }
};
// Verify Contact:
export const verifyContact = async (req, res) => {
    try {
        const { contact, OTP } = req.body;

        if (!contact) {
            return res.status(400).json({ success: false, message: "Contact number is required!" });
        }
        if (!OTP) {
            return res.status(400).json({ success: false, message: "OTP is required!" });
        }
        const user = await contactOtpverification.findOne({ contact });
        if (!user) {
            return res.status(404).json({ success: false, message: "Invalid contact number.", });
        }
        if (user.contactVerified) {
            return res.status(200).json({ success: true, message: "Contact is already verified.", });
        }
        if (!user.OTP || !user.otpExpiry) {
            return res.status(400).json({ success: false, message: "No OTP found. Please resend OTP.", });
        }
        if (Date.now() > new Date(user.otpExpiry).getTime()) {
            user.OTP = null;
            user.otpExpiry = null;
            await user.save();
            return res.status(400).json({ success: false, message: "OTP expired. Please resend OTP.", });
        }
        if (String(user.OTP).trim() !== String(OTP).trim()) {
            return res.status(400).json({ success: false, message: "Invalid OTP.", });
        }
        await contactOtpverification.updateOne(
            { contact },
            { $set: { contactVerified: true, OTP: null, otpExpiry: null } }
        );
        return res.status(200).json({ success: true, message: "Contact verified successfully.", });
    } catch (err) {
        console.error("Error during contact verification:", err);
        return res.status(500).json({
            success: false,
            message: err.message || "An unexpected server error occurred.",
        });
    }
};
// Resend OTP contact user
export const resendContactOTP = async (req, res) => {
    try {
        const { contact } = req.body;

        if (!contact || contact.trim() === "") {
            return res.status(400).json({ success: false, message: "Contact number is required." });
        }

        const contactRegex = /^[0-9]{10}$/;
        if (!contactRegex.test(contact)) {
            return res.status(400).json({ success: false, message: "Invalid contact number format." });
        }

        const user = await contactOtpverification.findOne({ contact });

        if (!user) {
            return res.status(404).json({ success: false, message: "User not found with this contact number." });
        }

        const fullContact = `+91${contact}`;
        const { otp: OTP, otpExpiry } = generateOTP();

        const sent = await sendOTP(OTP, fullContact);

        if (!sent) {
            return res.status(500).json({ success: false, message: "OTP not sent due to error." });
        }

        user.OTP = OTP;
        user.otpExpiry = otpExpiry;
        await user.save();

        return res.status(200).json({ success: true, message: "OTP sent successfully to contact number." });

    } catch (error) {
        console.error("Resend OTP Error:", error);
        return res.status(500).json({ success: false, message: "Internal server error." });
    }
};
// Login Request OTP
export const requestLoginOtp = async (req, res) => {
    const { email, contact } = req.body;

    if ((!email || email.trim() === '') && (!contact || contact.trim() === '')) {
        return res.status(400).json({ success: false, message: "Email or contact is required." });
    }
    try {
        let user = null;
        let contactData = null;
        const { otp: OTP, otpExpiry } = generateOTP();

        if (email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                return res.status(400).json({ success: false, message: "Invalid email format." });
            }

            user = await authModel.findOne({ email });

            if (!user) {
                return res.status(404).json({ success: false, message: "Email not registered!" });
            }

            if (!user.isVerified) {
                return res.status(403).json({ success: false, message: "Email not verified. Please verify your email first!" });
            }
            user.OTP = OTP;
            user.otpExpiry = otpExpiry;
            await user.save();

            await sendMail(email, OTP, 'login');
        }

        if (contact && !user) {
            const contactRegex = /^[0-9]{10}$/;
            if (!contactRegex.test(contact)) {
                return res.status(400).json({ success: false, message: "Invalid contact format." });
            }

            const fullContact = contact.startsWith('+') ? contact : `+91${contact}`;

            user = await authModel.findOne({ contact });
            contactData = await contactOtpverification.findOne({ contact, isVerified: true });

            if (!contactData) {
                return res.status(404).json({ success: false, message: "Contact number not found or not verified." });
            }

            contactData.OTP = OTP;
            contactData.otpExpiry = otpExpiry;
            await contactData.save();

            await sendOTP(OTP, fullContact, 'login');
        }

        return res.status(200).json({
            success: true,
            message: "OTP sent successfully for login."
        });

    } catch (err) {
        console.error("Login OTP Error:", err);
        return res.status(500).json({ success: false, message: "Server Error", data: err.message });
    }
};
// Login OTP User
export const userLoginOtp = async (req, res) => {
    const { email, contact, OTP } = req.body;
    if ((!email && !contact) || !OTP) {
        return res.status(400).json({ success: false, message: "Email or Contact and OTP are required." });
    }
    try {
        let user = null;
        if (email) {
            user = await authModel.findOne({ email });
            if (!user) {
                return res.status(404).json({ success: false, message: "Email not registered!" });
            }
            if (!user.isVerified) {
                return res.status(403).json({ success: false, message: "Email not verified. Please verify your email first!" });
            }
            if (user.OTP !== OTP || new Date() > user.otpExpiry) {
                return res.status(401).json({ success: false, message: "Invalid or expired OTP." });
            }
            user.OTP = null;
            user.otpExpiry = null;
            await user.save();
            return generateToken(user, "Login successful", 200, res);
        }
        if (contact) {
            const contactRegex = /^[0-9]{10}$/;
            if (!contactRegex.test(contact)) {
                return res.status(400).json({ success: false, message: "Invalid contact format." });
            }
            const contactData = await contactOtpverification.findOne({ contact, isVerified: true });
            const contactUser = await authModel.findOne({ contact });

            if (!contactData) {
                return res.status(404).json({ success: false, message: "Contact not Exits!" });
            }
            if (!contactUser) {
                return res.status(404).json({ success: false, message: "Contact not Exits!" });
            }
            if (contactData.OTP !== OTP || new Date() > contactData.otpExpiry) {
                return res.status(401).json({ success: false, message: "Invalid or expired OTP." });
            }
            contactData.OTP = null;
            contactData.otpExpiry = null;
            await contactData.save();
            const userFromContact = await authModel.findOne({ contact });
            if (!userFromContact) {
                return res.status(404).json({ success: false, message: "User not found for this contact." });
            }
            return generateToken(userFromContact, "Login successful!", 200, res);
        }
    } catch (err) {
        console.error("Login Verify OTP Error:", err);
        return res.status(500).json({ success: false, message: "Server Error", data: err.message });
    }
};
// Get user by id
export const getUserprofile = async (req, res) => {
    try {
        const userId = req.userId;
        if (!userId) {
            return res.status(400).json({ success: false, message: "User ID is required." });
        }
        const user = await authModel.findById(userId).lean();
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found." });
        }
        const contactData = await contactOtpverification.findOne({ contact: user.contact }).lean();
        user.contactVerified = contactData?.contactVerified || false;
        return res.status(200).json({ success: true, message: "Data Retrieved successfully", data: user, });
    } catch (error) {
        console.error("Error retrieving user:", error);
        return res.status(500).json({ success: false, message: "Failed to retrieve user.", error: error.message, });
    }
};
// Login With Google ::
export const googleLogin = async (req, res) => {
    try {
        const { token } = req.body;
        if (!token) {
            return res.status(400).json({ success: false, message: "Token is required" });
        }
        const ticket = await client.verifyIdToken({ idToken: token, audience: config.googleClientId, });
        const payload = ticket.getPayload();
        const { email, socialName, picture } = payload;
        let user = await authModel.findOne({ email });
        if (!user) {
            user = await authModel.create({ email, socialName, profilePic: picture, provider: "google", isVerified: true, });
        } else {
            user.socialName = socialName || user.name;
            user.profilePic = picture || user.profilePic;
            user.provider = "google";
            user.isVerified = true;
            await user.save();
        }
        const jwtToken = generateTokenGoogle(user._id);
        return res.status(200).json({ success: true, message: "Google login successful", token: jwtToken, user, userId: user._id, });
    } catch (error) {
        console.error("Google Login Error:", error);
        return res.status(500).json({
            success: false,
            message: error.message || "Internal Server Error",
        });
    }
};
// Login With Facebook ::
export const facebookLogin = async (req, res) => {
    try {
        const { accessToken } = req.body;
        if (!accessToken) {
            return res.status(400).json({ success: false, message: "Access token is required", });
        }
        const debugUrl = `https://graph.facebook.com/debug_token?input_token=${accessToken}&access_token=${config.facebookAppId}|${config.facebookAppSecret}`;
        const debugResponse = await axios.get(debugUrl);
        if (!debugResponse.data.data.is_valid) {
            return res.status(401).json({ success: false, message: "Invalid Facebook access token", });
        }
        const userInfoUrl = `https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`;
        const userInfo = await axios.get(userInfoUrl);
        const { id, socialName, email, picture } = userInfo.data;
        let user;
        if (email) {
            user = await authModel.findOne({ email });
        } else {
            user = await authModel.findOne({ providerId: id });
        }
        if (!user) {
            user = await authModel.create({
                socialName,
                email: email || "",
                profilePic: picture?.data?.url || "",
                provider: "facebook",
                providerId: id,
                isVerified: true,
            });
        } else {
            user.socialName = socialName || user.name;
            user.profilePic = picture?.data?.url || user.profilePic;
            user.provider = "facebook";
            user.providerId = id;
            user.isVerified = true;
            await user.save();
        }
        const token = generateTokenGoogle(user._id);
        return res.status(200).json({ success: true, message: "Facebook login successful", token, user, });
    } catch (error) {
        console.error("Facebook Login Error:", error.response?.data || error.message);
        return res.status(500).json({ success: false, message: error.message || "Internal server error", });
    }
};







