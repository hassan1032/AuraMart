import AWS from 'aws-sdk';
import fs from 'fs';
import { awsConfig } from '../configs/aws.config.js';

AWS.config.update({
    accessKeyId: awsConfig.accessKeyId,
    secretAccessKey: awsConfig.secretAccessKey,
});
const s3 = new AWS.S3();
const isMediaFile = (mimetype) => {
    const allowedMediaTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/mpeg', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska',];
    return allowedMediaTypes.includes(mimetype);
};
export const upload = (files) => {
    return new Promise((resolve, reject) => {
        let file = null;
        let folder = "";

        if (files.document && isMediaFile(files.document[0].mimetype)) {
            file = files.document[0];
            folder = "documents";
        }
        else if (files.governmentIdImage && isMediaFile(files.governmentIdImage[0].mimetype)) {
            file = files.governmentIdImage[0];
            folder = "images";
        }
        else if (files.image && isMediaFile(files.image[0].mimetype)) {
            file = files.image[0];
            folder = "images";
        }
        else if (files.video && isMediaFile(files.video[0].mimetype)) {
            file = files.video[0];
            folder = "videos";
        }

        if (file) {
            const params = {
                Bucket: awsConfig.bucket,
                Key: `${folder}/${Date.now()}_${file.originalFilename}`,
                Body: fs.createReadStream(file.filepath),
                ContentType: file.mimetype,
            };

            s3.upload(params, (err, data) => {
                if (err) {
                    console.error("❌ S3 Upload Error:", err);
                    reject("File not uploaded");
                } else {
                    resolve(data.Location);
                }
            });
        } else {
            reject("Invalid file type.");
        }
    });
};
