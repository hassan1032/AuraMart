import nodemailer from 'nodemailer';
import ejs from 'ejs';
import path from 'path';
import { fileURLToPath } from 'url';
import { emailConfig } from '../configs/mailer.config.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const transporter = nodemailer.createTransport({
    service: emailConfig.service,
    auth: {
        type: emailConfig.type,
        clientId: emailConfig.clientId,
        clientSecret: emailConfig.clientSecret,
    },
});

const auth = {
    user: emailConfig.user,
    refreshToken: emailConfig.refreshToken,
    accessToken: emailConfig.accessToken,
    expires: emailConfig.expires,
};

export const sendMail = (receiver, OTP, type) => {
    return new Promise((resolve, reject) => {
        if (type === 'forgot_password' || type === 'signup' || type === "verification" || type === "resend_otp" || type === "login") {
            const templatePath = path.join(__dirname, '../templates/otp.ejs');

            ejs.renderFile(templatePath, { OTP }).then((template) => {

                const subject =
                    type === 'forgot_password'
                        ? 'Forgot Password OTP!'
                        : type === 'resend_otp'
                            ? 'Resend OTP - Nicki Macfarlane'
                            : type === 'signup'
                                ? 'Signup Verification - Nicki Macfarlane'
                                : type === 'verification'
                                    ? 'Email Verification - Nicki Macfarlane'
                                    : type === 'login'
                                        ? 'Login OTP - Nicki Macfarlane'
                                        : 'OTP Code - Nicki Macfarlane';

                transporter.sendMail({
                    from: `Nicki Macfarlane Team <${emailConfig.user}>`,
                    to: receiver,
                    subject,
                    html: template,
                    auth: auth,
                }).then((send) => {
                    resolve(send);
                }).catch((error) => {
                    reject(error);
                });
            }).catch((error) => {
                reject(error);
            });
        } else {
            console.warn('Invalid email type received:', type);
            reject('Invalid email type');
        }
    });
};
// Tracking Mail function ::
export const sendTrackingMail = async (receiver, order, trackingNumber, estimatedDelivery) => {
    try {
        const templatePath = path.join(__dirname, "../templates/otp.ejs");
        console.log("Rendering template from:", templatePath);
        const orderIdentifier = order?.orderCode || order?._id;
        const template = await ejs.renderFile(templatePath, {
            orderId: orderIdentifier,
            trackingNumber,
            estimatedDelivery,
            tracking: true
        });
        const subject = "Verification & Shipment Notification - Nicki Macfarlane";
        await transporter.sendMail({ from: `Nicki Macfarlane Team <${emailConfig.user}>`, to: receiver, subject, html: template, auth: auth });
        return true;
    } catch (error) {
        console.error("❌ Error sending tracking mail:", error);
        throw error;
    }
};


