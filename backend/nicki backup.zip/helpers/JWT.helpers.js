import jwt from "jsonwebtoken";
import config from "../configs/JWT.config.js";
// User Token ::
export const generateToken = (user, message, statusCode, res) => {
    const token = jwt.sign(
        { userId: user._id, email: user.email, role: user.role },
        config.jwtSecretKey,
        { expiresIn: "15d" }
    );
    res.status(statusCode)
        .cookie("token", token, { expire: new Date(Date.now() + config.cookieExpire * 24 * 60 * 60 * 1000), httpOnly: true, })
        .json({ success: true, message, token, userId: user._id, });
};
// Google Genrate Token ::
export const generateTokenGoogle = (userId) => {
    return jwt.sign({ id: userId }, config.jwtSecretKey, { expiresIn: "15d" });
};
// Employee Token 
export const generateTokenEmployee = (employee, message, statusCode, res) => {
    try {
        const token = jwt.sign(
            {
                employeeId: employee._id.toString(),
                email: employee.email,
                roleType: employee.role?.roleName || "Unknown",
            },
            config.jwtSecretKey,
            { expiresIn: "7d" }
        );
        res.status(statusCode)
            .cookie("token", token, { expire: new Date(Date.now() + config.cookieExpire * 24 * 60 * 60 * 1000), httpOnly: true, })
            .json({
                success: true,
                message,
                token,
                employee: {
                    id: employee._id,
                    name: employee.name,
                    email: employee.email,
                    role: {
                        roleName: employee.role?.roleName || "Unknown",
                        permissions: employee.role?.permissions || [],
                    },
                },
            });
    } catch (error) {
        console.error("GenerateTokenEmployee Error:", error);
        res.status(500).json({ success: false, message: "Token generation failed.", });
    }
};





