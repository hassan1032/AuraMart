import axios from "axios";
import { DHL_CONFIG } from "../configs/DHL.config.js";


const generateDemoTracking = (orderId) => {
    const rnd = Math.floor(Math.random() * 900000 + 100000);
    return `${DHL_CONFIG.sandboxDemoTrackingPrefix}${Date.now().toString().slice(-6)}${rnd}`;
};

export const createShipment = async (order) => {
    if (DHL_CONFIG.environment === "sandbox") {
        return {
            success: true,
            trackingNumber: generateDemoTracking(order._id.toString()),
            raw: { mock: true, orderId: order._id.toString() },
        };
    }
    try {
        const url = `${DHL_CONFIG.baseURL}${DHL_CONFIG.createShipmentPath}`;
        const payload = {
            shipper: {
                name: "Your Company Name",
                postalAddress: {
                    addressLine1: "Your Address Line 1",
                    cityName: "Your City",
                    postalCode: "12345",
                    countryCode: "IN",
                },
                contact: {
                    phone: "+911234567890",
                    email: "support@yourdomain.com",
                },
            },
            receiver: {
                name: order.shippingAddress?.name,
                postalAddress: {
                    addressLine1: order.shippingAddress?.addressLine,
                    cityName: order.shippingAddress?.city,
                    postalCode: order.shippingAddress?.postalCode,
                    countryCode:
                        order.shippingAddress?.countryCode ||
                        order.shippingAddress?.country,
                },
                contact: {
                    phone: order.shippingAddress?.phone,
                    email: order.shippingAddress?.email,
                },
            },
            content: "Order Shipment",
            pieces: [
                {
                    weight: 1, // Optional: calculate from order.items
                    dimensions: { length: 10, width: 10, height: 10 },
                },
            ],
        };

        const resp = await axios.post(url, payload, {
            headers: {
                "Content-Type": "application/json",
                "DHL-API-Key": DHL_CONFIG.apiKey,
            },
        });

        return {
            success: true,
            trackingNumber:
                resp.data?.shipmentTrackingNumber ||
                resp.data?.id ||
                null,
            raw: resp.data,
        };
    } catch (error) {
        console.error("DHL createShipment error:", error?.response?.data || error.message);
        return {
            success: false,
            message: "Failed to create DHL shipment",
            raw: error?.response?.data || null,
        };
    }
};

/**
 * Track Shipment (Sandbox or Production)
 */
export const trackShipment = async (trackingNumber) => {
    if (!trackingNumber) throw new Error("trackingNumber required");

    // SANDBOX MOCK DATA
    if (DHL_CONFIG.environment === "sandbox") {
        const now = new Date();
        return {
            success: true,
            trackingNumber,
            shipments: [
                {
                    id: trackingNumber,
                    status: {
                        statusCode: "in_transit",
                        status: "In Transit",
                        description: "Shipment currently in transit (mock)",
                    },
                    estimatedTimeOfDelivery: new Date(now.getTime() + 2 * 86400000).toISOString(),
                    events: [
                        {
                            timestamp: new Date(now.getTime() - 48 * 3600000).toISOString(),
                            description: "Shipment created (mock)",
                            location: "Warehouse",
                        },
                        {
                            timestamp: new Date(now.getTime() - 24 * 3600000).toISOString(),
                            description: "Picked up (mock)",
                            location: "Local hub",
                        },
                        {
                            timestamp: now.toISOString(),
                            description: "In transit (mock)",
                            location: "Regional hub",
                        },
                    ],
                    rawShipment: { mock: true },
                },
            ],
            raw: { mock: true },
        };
    }

    // PRODUCTION TRACK API CALL
    try {
        const url = `${DHL_CONFIG.baseURL}${DHL_CONFIG.trackPath}?trackingNumber=${encodeURIComponent(trackingNumber)}`;
        const resp = await axios.get(url, {
            headers: { "DHL-API-Key": DHL_CONFIG.apiKey },
        });

        const raw = resp.data;
        const shipments = raw?.shipments ?? [];
        const normalized = shipments.map((s) => ({
            id: s?.id ?? trackingNumber,
            status: s?.status ?? null,
            estimatedTimeOfDelivery: s?.estimatedTimeOfDelivery ?? null,
            events: s?.events ?? [],
            rawShipment: s,
        }));

        return { success: true, trackingNumber, shipments: normalized, raw };
    } catch (error) {
        console.error("DHL trackShipment error:", error?.response?.data || error.message);
        return {
            success: false,
            message: "Failed to track DHL shipment",
            raw: error?.response?.data || null,
        };
    }
};
