import { MongoClient } from 'mongodb';
import promptSync from 'prompt-sync';
import { dbConfig } from '../_configs/seeder.config.js';

const prompt = promptSync({ sigint: true });
const accessPassword = prompt('🔐 Enter access password: ');

if (accessPassword !== dbConfig.password) {
    console.log('❌ Invalid password. Access denied.');
    process.exit(1);
}

const sourceUri = `mongodb+srv://${dbConfig.source.user}:${dbConfig.source.pass}@${dbConfig.source.cluster}/${encodeURIComponent(dbConfig.source.dbName)}?retryWrites=true&w=majority`;
const targetUri = `mongodb+srv://${dbConfig.target.user}:${dbConfig.target.pass}@${dbConfig.target.cluster}/${encodeURIComponent(dbConfig.target.dbName)}?retryWrites=true&w=majority`;

const mongoOptions = {
    serverApi: { version: '1' },
};

async function migrateData() {
    const sourceClient = new MongoClient(sourceUri, mongoOptions);
    const targetClient = new MongoClient(targetUri, mongoOptions);

    try {
        await sourceClient.connect();
        await targetClient.connect();
        console.log('✅ Connected to source and target DBs');

        const sourceDb = sourceClient.db(dbConfig.source.dbName);
        const targetDb = targetClient.db(dbConfig.target.dbName);

        const collections = await sourceDb.listCollections().toArray();
        console.log(`📋 Found ${collections.length} collections in source database.`);

        for (const { name } of collections) {
            console.log(`📦 Checking collection: ${name}`);
            const sourceCollection = sourceDb.collection(name);
            const targetCollection = targetDb.collection(name);

            const docs = await sourceCollection.find({}).toArray();
            console.log(`🔍 Found ${docs.length} documents in source collection '${name}'`);

            if (docs.length > 0) {
                await targetCollection.deleteMany({});
                await targetCollection.insertMany(docs);
                console.log(`✅ Migrated ${docs.length} documents to target collection '${name}'`);
            } else {
                console.log(`⚠️ Skipped '${name}' - no documents found`);
            }
        }
        console.log('🎉 Migration complete!');
    } catch (err) {
        console.error('❌ Error during migration:', err.message || err);
    } finally {
        await sourceClient.close();
        await targetClient.close();
        console.log('🔒 Connections closed');
    }
}
migrateData();
