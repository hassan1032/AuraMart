import AWS from 'aws-sdk';
import promptSync from 'prompt-sync';
import { s3Config } from '../configs/seeder.config.js';
import pLimit from 'p-limit';

const prompt = promptSync({ sigint: true });
const accessPassword = prompt('🔐 Enter access password: ');

if (accessPassword !== s3Config.password) {
    console.log('❌ Invalid password. Access denied.');
    process.exit(1);
}
const sourceS3 = new AWS.S3({
    accessKeyId: s3Config.source.accessKeyId,
    secretAccessKey: s3Config.source.secretAccessKey,
    region: s3Config.source.region,
});
const targetS3 = new AWS.S3({
    accessKeyId: s3Config.target.accessKeyId,
    secretAccessKey: s3Config.target.secretAccessKey,
    region: s3Config.target.region,
});
const sourceBucket = s3Config.source.bucket;
const targetBucket = s3Config.target.bucket;
const limit = pLimit(100);

async function migrateS3Objects() {
    try {
        const list = await sourceS3.listObjectsV2({ Bucket: sourceBucket }).promise();
        const allObjects = list.Contents || [];

        console.log(`📦 Found ${allObjects.length} objects. Starting migration...`);

        const uploadTasks = allObjects.map(obj => limit(async () => {
            const key = obj.Key;

            try {
                const file = await sourceS3.getObject({ Bucket: sourceBucket, Key: key }).promise();

                await targetS3.putObject({
                    Bucket: targetBucket,
                    Key: key,
                    Body: file.Body,
                    ContentType: file.ContentType,
                }).promise();

                console.log(`✅ Migrated: ${key}`);
            } catch (err) {
                console.error(`❌ Failed: ${key}`, err.message);
            }
        }));

        await Promise.all(uploadTasks);
        console.log('🎉 All objects migrated successfully!');
    } catch (err) {
        console.error('❌ Migration failed:', err.message || err);
    }
}

migrateS3Objects();
