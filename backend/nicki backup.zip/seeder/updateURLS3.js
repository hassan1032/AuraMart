import { MongoClient } from "mongodb";

const uri =
    "mongodb+srv://mackfrlane:8Bvf69bkZgNjFX6W@mackfrnlane.rkfof5k.mongodb.net/mackfarlane";
const dbName = "mackfarlane";
const collectionName = "collections";

const OLD_URL = "https://nicki1.s3.eu-north-1.amazonaws.com/images/";
const NEW_URL = "https://nickibucket12.s3.eu-north-1.amazonaws.com/images/";

// ✅ Define all fields that may contain URLs
const FIELDS = ["thumbnail", "productschemas"];

async function updateImageURLs() {
    const client = new MongoClient(uri);

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(collectionName);

        let totalUpdated = 0;

        for (const field of FIELDS) {
            const result = await collection.updateMany(
                { [field]: { $regex: OLD_URL } }, // match field with OLD_URL
                [
                    {
                        $set: {
                            [field]: {
                                $cond: [
                                    { $isArray: `$${field}` }, // agar array hai to map karo
                                    {
                                        $map: {
                                            input: `$${field}`,
                                            as: "img",
                                            in: {
                                                $replaceOne: {
                                                    input: "$$img",
                                                    find: OLD_URL,
                                                    replacement: NEW_URL,
                                                },
                                            },
                                        },
                                    },
                                    {
                                        $replaceOne: {
                                            input: `$${field}`, // single string case
                                            find: OLD_URL,
                                            replacement: NEW_URL,
                                        },
                                    },
                                ],
                            },
                        },
                    },
                ]
            );

            console.log(`✅ Field '${field}' → Updated ${result.modifiedCount} documents.`);
            totalUpdated += result.modifiedCount;
        }

        console.log(`🎉 Total Updated Documents: ${totalUpdated}`);
    } catch (error) {
        console.error("❌ Error updating image URLs:", error);
    } finally {
        await client.close();
    }
}

updateImageURLs();
